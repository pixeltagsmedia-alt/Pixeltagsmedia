repo: pixeltagsmedia-alt/Pixeltagsmedia
branch: main

## Last sync
date: 2026-09-01T05:53:15Z

### Updated in this project
- Rebuilt the homepage as an editable design component (`PixelTagsMedia.dc.html`)
- Extracted the 9 embedded platform logos into real PNGs under `logos/`
- Fixed the scroll-reveal animation (content no longer blanks in print/export)
- Added responsive nav + section padding for mobile
- Produced `index.html`, a single self-contained file ready for GitHub Pages

## Screen map
| Project screen | Repo files |
| --- | --- |
| PixelTagsMedia.dc.html (homepage) | pixeltagsmedia_home_1.html |
| index.html (standalone build) | pixeltagsmedia_home_1.html |
